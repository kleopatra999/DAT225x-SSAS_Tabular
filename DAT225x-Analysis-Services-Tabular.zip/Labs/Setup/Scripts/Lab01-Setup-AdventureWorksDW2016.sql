PRINT N'Create the NT SERVICE\MSOLAP$TABULAR user';
GO
IF EXISTS(SELECT * FROM [sys].[sysusers] WHERE [name] = N'NT SERVICE\MSOLAP$TABULAR')
BEGIN
	PRINT N'** User already exists - user not created **';
END
ELSE
BEGIN
	CREATE USER [NT SERVICE\MSOLAP$TABULAR] FOR LOGIN [NT SERVICE\MSOLAP$TABULAR]
		WITH DEFAULT_SCHEMA=[dbo];
END;
GO

PRINT N'Add the NT SERVICE\MSOLAP$TABULAR user to the db_datareader role';
GO
ALTER ROLE [db_datareader]
	ADD MEMBER [NT SERVICE\MSOLAP$TABULAR];
GO

PRINT N'Update one employee (286) record LoginID';
GO
SET NOCOUNT ON;
GO
UPDATE
	[dbo].[DimEmployee]
SET
	[LoginID] = SUSER_SNAME()
WHERE
	[EmployeeKey] = 286;
GO
SET NOCOUNT OFF;
GO