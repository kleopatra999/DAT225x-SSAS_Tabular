USE [AdventureWorksDW2016];
GO

CREATE VIEW [dbo].[vCorporateDate]
AS
	SELECT
		[DateKey],
		[FullDateAlternateKey] AS [Date],
		CAST([CalendarYear] AS NCHAR(4)) + N' ' + LEFT([EnglishMonthName], 3) + N', ' + CASE WHEN [DayNumberOfMonth] < 10 THEN N'0' ELSE N'' END + CAST([DayNumberOfMonth] AS NVARCHAR(2)) AS [DateLabel],
		(([CalendarYear] * 100) + [MonthNumberOfYear]) AS [MonthKey],
		CAST([CalendarYear] AS NCHAR(4)) + N' ' + LEFT([EnglishMonthName], 3) AS [MonthLabel],
		[MonthNumberOfYear] AS [MonthOfYearKey],
		LEFT([EnglishMonthName], 3) AS [MonthOfYearLabel],
		(([CalendarYear] * 10) + [CalendarQuarter]) AS [CalendarQuarterKey],
		N'CY' + CAST([CalendarYear] AS NCHAR(4)) + N' Q' + CAST([CalendarQuarter] AS NCHAR(1)) AS [CalendarQuarterLabel],
		[CalendarQuarter] AS [CalendarQuarterOfYearKey],
		N'CY Q' + CAST([CalendarQuarter] AS NCHAR(1)) AS [CalendarQuarterOfYearLabel],
		[CalendarYear] AS [CalendarYearKey],
		N'CY' + CAST([CalendarYear] AS NCHAR(4)) AS [CalendarYearLabel],
		(([FiscalYear] * 10) + [FiscalQuarter]) AS [FiscalQuarterKey],
		N'FY' + CAST([FiscalYear] AS NCHAR(4)) + N' Q' + CAST([FiscalQuarter] AS NCHAR(1)) AS [FiscalQuarterLabel],
		[FiscalQuarter] AS [FiscalQuarterOfYearKey],
		N'FY Q' + CAST([FiscalQuarter] AS NCHAR(1)) AS [FiscalQuarterOfYearLabel],
		[FiscalYear] AS [FiscalYearKey],
		N'FY' + CAST([FiscalYear] AS NCHAR(4)) AS [FiscalYearLabel]
	FROM
		[dbo].[DimDate];
GO

SELECT * FROM [dbo].[vCorporateDate];
GO
